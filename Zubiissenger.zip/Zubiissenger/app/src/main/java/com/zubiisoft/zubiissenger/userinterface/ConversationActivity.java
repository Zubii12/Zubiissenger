package com.zubiisoft.zubiissenger.userinterface;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.zubiisoft.zubiissenger.R;

/**
 * ConversationActivity. Show all available conversations.
 *
 */
public class ConversationActivity extends AppCompatActivity {

    /**
     * Create the content view, inflate the activity UI.
     *
     * @param savedInstanceState Saved instance state bundle.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation);
    }
}