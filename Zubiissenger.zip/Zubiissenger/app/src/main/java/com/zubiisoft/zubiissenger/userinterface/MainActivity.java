package com.zubiisoft.zubiissenger.userinterface;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.zubiisoft.zubiissenger.R;

/**
 * Main Activity to choose Login or Register if the user is not already login.
 */
public class MainActivity extends AppCompatActivity {

    // Tag for log chat.
    private static final String TAG = "MainActivity";

    /**
     *  Create the content view, inflate the activity UI.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    /**
     * Launch the LoginActivity.
     * @param view The Button view.
     */
    public void startLoginButton(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    /**
     * Launch the RegisterActivity.
     * @param view The Button view.
     */
    public void startRegisterButton(View view) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}