package com.zubiisoft.zubiissenger;

import android.app.Application;

/**
 * Android Application class. Used for accessing singletons.
 */
public class MyApplication  extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }

}
