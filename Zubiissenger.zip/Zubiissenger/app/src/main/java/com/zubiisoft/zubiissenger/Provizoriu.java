/**
package com.zubiisoft.zubiissenger.userinterface;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.ValueEventListener;
import com.zubiisoft.zubiissenger.R;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private FirebaseAnalytics mFirebaseAnalytics;
    FirebaseDatabase database;
    DatabaseReference myRef;

    @IgnoreExtraProperties
    private static class Zubii{
        private String nume;
        private String prenume;

        Zubii(){

        }

        Zubii(String nume, String prenume){
            this.nume = nume;
            this.prenume = prenume;
        }

        public String getNume() {
            return nume;
        }

        public String getPrenume() {
            return prenume;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
        try {
            Log.d(TAG + "zzz", myRef.getDatabase().toString());

            Zubii zzz = new Zubii("nume1", "prenume1");

            myRef.child("zubii").child("id1").child("nume").setValue("zubiiNume");

            myRef.child("zubii").child("id2").child("prenume").setValue("mi-am schimbat" +
                    "prenumele");

        } catch (Exception e){
            Log.d(TAG + "zzz eroare", e.getMessage());
        }
        //myRef.setValue("Hello, World!");
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, "1");
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "zbii");
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "image");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void startLoginButton(View view) {
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = (String) dataSnapshot.child("zubii").child("id1").child("nume").getValue();
                try {
                    Zubii value2 = dataSnapshot.child("zubii").child("id2").getValue(Zubii.class);

                    Log.d(TAG + "zzz", "nume: " + value2.getNume()  + "prenume: " + value2.getPrenume());

                } catch (Exception e) {
                    Log.d(TAG + "zzz error", e.getMessage());
                }
                //Log.d(TAG + "zzz", "Value is: " + value);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
        //Intent intent = new Intent(this, LoginActivity.class);
        //startActivity(intent);
    }

    public void startRegisterButton(View view) {
        Toast.makeText(this, "Feature disable", Toast.LENGTH_SHORT).show();
    }
}
*/