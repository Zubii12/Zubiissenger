package com.zubiisoft.zubiissenger.userinterface;

public class ConversationAdapter extends RecyclerView.Adapter {
}
