package com.zubiisoft.zubiissenger.userinterface;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.zubiisoft.zubiissenger.R;

/**
 * Register Activity for create new accounts.
 */
public class RegisterActivity extends AppCompatActivity {

    // Tag for log chat.
    private static final String TAG = "RegisterActivity";

    // Instance of Email and Password for create a new account.
    private EditText mEmail;
    private EditText mPassword;

    // Instance of FirebaseAuth;
    private FirebaseAuth mAuth;

    /**
     *  Create the content view, inflate the activity UI.
     * @param savedInstanceState Saved instance state bundle.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Get an instance of Auth.
        mAuth = FirebaseAuth.getInstance();

        // Get an instance of EditText.
        mEmail = findViewById(R.id.email_editText);
        mPassword = findViewById(R.id.password_editText);

    }

    /**
     * Get the strings from EditText and pass them to the createAccount.
     *
     * @param view The Button view.
     */
    public void registerButton(View view) {
        // Get the text from mEmail and mPassword.
        String email = mEmail.getText().toString();
        String password = mPassword.getText().toString();

        // Create an account.
        createAccount(email, password);
    }

    /**
     * Create an account with specified email and password.
     * @param email
     * @param password
     */
    private void createAccount(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "createUserWithEmail:success");
                            Toast.makeText(RegisterActivity.this,
                                    "Authentication successful.",
                                    Toast.LENGTH_LONG).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            //updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(RegisterActivity.this,
                                    "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }

                        // ...
                    }
                });
    }

}