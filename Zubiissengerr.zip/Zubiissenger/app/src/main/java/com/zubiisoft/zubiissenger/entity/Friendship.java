package com.zubiisoft.zubiissenger.entity;

public class Friendship {
    private String idFriend;
}
